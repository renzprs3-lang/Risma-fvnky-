# AZKA RMX DJ PRO Android

Android WebView wrapper for the AZKA RMX DJ PRO local music player.

## Build
Run `gradle assembleDebug` with JDK 17 and Android SDK installed, or use the GitHub Actions workflow supplied separately. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The app loads its DJ interface from `app/src/main/assets/index.html`, supports choosing audio files from the device, and downloads recorded mixes through Android Download Manager. Recording format is browser-supported WebM or Ogg, not MP3.
